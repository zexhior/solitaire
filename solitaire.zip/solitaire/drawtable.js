export let drawtable = (dimension)=>{
    let table = document.querySelector('table')
    for(let i = 0; i < dimension; i++){
        let tr = document.createElement('tr')
        for(let j = 0; j < dimension; j++){
            let td = document.createElement('td')
            if((i === 0 && j === 2)||
            (i === 0 && j === 3)||
            (i === 0 && j === 4)||
            (i === 1 && j === 2)||
            (i === 1 && j === 3)||
            (i === 1 && j === 4)||
            i === 2 ||
            i === 3 ||
            i === 4 ||
            (i === 5 && j === 2)||
            (i === 5 && j === 3)||
            (i === 5 && j === 4)||
            (i === 6 && j === 2)||
            (i === 6 && j === 3)||
            (i === 6 && j === 4)
            ){
                let div = document.createElement('div')
                div.classList.add('circle')
                td.appendChild(div)
                if(i==3 && j==3){
                    td.style.backgroundColor = "red"
                }
                td.style.border = "1px solid black"
            }
            td.style.padding = "20px"
            tr.appendChild(td)
        }
        table.appendChild(tr)
    }
}