let dimension = 7
let drawtable = ()=>{
    let table = document.querySelector('table')
    for(let i = 0; i < dimension; i++){
        let tr = document.createElement('tr')
        for(let j = 0; j < dimension; j++){
            let td = document.createElement('td')
            if((i === 0 && j === 2)||
            (i === 0 && j === 3)||
            (i === 0 && j === 4)||
            (i === 1 && j === 2)||
            (i === 1 && j === 3)||
            (i === 1 && j === 4)||
            i === 2 ||
            i === 3 ||
            i === 4 ||
            (i === 5 && j === 2)||
            (i === 5 && j === 3)||
            (i === 5 && j === 4)||
            (i === 6 && j === 2)||
            (i === 6 && j === 3)||
            (i === 6 && j === 4)
            ){
                let div = document.createElement('div')
                div.classList.add('circle')
                td.appendChild(div)
                if(i==3 && j==3){
                    td.style.backgroundColor = "red"
                }
                td.style.border = "1px solid black"
            }
            td.style.padding = "20px"
            tr.appendChild(td)
        }
        table.appendChild(tr)
    }
}

let findEmptySpace = (matrice)=>{
    let iter = []
    let i = 0;
    let j = 0;
    matrice.forEach(data=>{
        if(j === 7){
            i++
            j = 0
        }
        if(data === 2)
            iter.push({i: i,j : j})
        j++
    })
    return iter
}

let getPosition = (i,j,distance)=>{
    let up = (i-distance)*7+j
    let right = i*7+j+distance
    let left = i*7+j-distance
    let down = (i+distance)*7+j
    return {up: up, right: right, left: left, down: down}
}

let findNextTurn = (empty,matrice)=>{
    let iter = []
    empty.map(data=>{
        let nxt = []
        first_position = getPosition(data.i,data.j,1)
        second_position = getPosition(data.i,data.j,2)
        /************* test up **************/
        if(matrice[first_position.up] === 1 && 
        matrice[second_position.up] === 1 &&
        first_position.up > 0 && second_position.up > 0){
            nxt.push({position:'up', i: data.i-2, j: data.j})
        }
        if(matrice[first_position.down] === 1 && 
        matrice[second_position.down] === 1 &&
        second_position.down < 7*7 && second_position.down < 7*7){
            nxt.push({position:'down', i: data.i+2, j: data.j})
        }
        if(matrice[first_position.left] === 1 && 
        matrice[second_position.left] === 1 &&
        parseInt(first_position.left/7) === parseInt((first_position.left+1)/7) && 
        parseInt(second_position.left/7) === parseInt((second_position.left+2)/7)){
            nxt.push({position:'left', i: data.i, j: data.j-2})
        }
        if(matrice[first_position.right] === 1 && 
        matrice[second_position.right] === 1 &&
        parseInt(first_position.right/7) == parseInt((first_position.right-1)/7) && 
        parseInt(second_position.right/7) == parseInt((second_position.right-2)/7)){
            nxt.push({position:'right', i: data.i, j: data.j+2})
        }
        iter.push(nxt)
    })
    return iter
}

let showNext = (next)=>{
    let tds = document.querySelectorAll('td')
    next.map(data=>{
        console.log('vide')
        data.map(point=>{
            tds[point.i*7+point.j].style.backgroundColor = 'blue'
        })
    })
}

let removeNext = (next,tds)=>{
    next.map(data=>{
        data.map(point=>{
            tds[point.i*7+point.j].style.backgroundColor = ''
        })
    })
}

let move = (point,tds,matrice)=>{
    let pos1 = 0
    let pos2 = 0
    let pos3 = 0     
    if(point.position == 'right'){
        pos1 = point.i*7+point.j
        pos2 = point.i*7+point.j-1
        pos3 = point.i*7+point.j-2      
    }
    else if(point.position == 'left'){
        pos1 = point.i*7+point.j
        pos2 = point.i*7+point.j+1
        pos3 = point.i*7+point.j+2      
    }
    else if(point.position == 'up'){
        pos1 = point.i*7+point.j
        pos2 = (point.i+1)*7+point.j
        pos3 = (point.i+2)*7+point.j    
    }
    else if(point.position == 'down'){
        pos1 = point.i*7+point.j
        pos2 = (point.i-1)*7+point.j
        pos3 = (point.i-2)*7+point.j     
    }
    console.log(pos1)
    console.log(pos2)
    console.log(pos3)
    tds[pos1].style.backgroundColor = 'red'
    tds[pos2].style.backgroundColor = 'red'
    tds[pos3].style.backgroundColor = ''
    matrice[pos1] = 2
    matrice[pos2] = 2
    matrice[pos3] = 1   
}

let showMatrice = (matrice)=>{
    let j = 0
    for(let i = 0; i < 7; i ++){
        console.log(`${matrice[i*7+0]} ${matrice[i*7+1]} ${matrice[i*7+2]} ${matrice[i*7+3]} ${matrice[i*7+4]} ${matrice[i*7+5]} ${matrice[i*7+6]}`)
    }
}

drawtable()

let tbs = document.querySelectorAll('td')
let matrice = []
for(let i = 0; i < tbs.length; i++){
    if(i === 0 || i === 1 || i === 5 ||i === 6 ||
        i === 7 || i === 8 || i === 12 || i === 13 ||
        i === 35 || i === 36 || i === 40 || i === 41 ||
        i === 42 || i === 43 || i === 47 || i === 48){
            matrice.push(0)
    }
    else if(i === 3*7+3){
        matrice.push(2)
    }
    else{
        matrice.push(1)
    }
}

showMatrice(matrice)
let empty = findEmptySpace(matrice)
let next = findNextTurn(empty,matrice)
let tds = document.querySelectorAll('td')
showNext(next)
let iteration = 0
window.setInterval(()=>{
    if(iteration == 0){
        removeNext(next,tds)
        move(next[0][3],tds,matrice)
        empty = findEmptySpace(matrice)
        console.log(empty)
        next = findNextTurn(empty,matrice)
        showNext(next)
    }else if(iteration == 1){
        removeNext(next,tds)
        move(next[0][0],tds,matrice)
        empty = findEmptySpace(matrice)
        console.log(empty)
        next = findNextTurn(empty,matrice)
        showNext(next)
    }else if(iteration == 2){
        removeNext(next,tds)
        move(next[0][0],tds,matrice)
        empty = findEmptySpace(matrice)
        console.log(empty)
        next = findNextTurn(empty,matrice)
        showNext(next)
    }
    iteration++;
},(1000))