export let findEmptySpace = (matrice)=>{
    let iter = []
    let i = 0;
    let j = 0;
    matrice.forEach(data=>{
        if(j === 7){
            i++
            j = 0
        }
        if(data === 2)
            iter.push({i: i,j : j})
        j++
    })
    return iter
}